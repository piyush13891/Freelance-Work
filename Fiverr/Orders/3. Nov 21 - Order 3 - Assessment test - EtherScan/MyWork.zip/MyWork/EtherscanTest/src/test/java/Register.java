import PageObjects.RegisterPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.*;
import java.time.Duration;

public class Register {

    WebDriver driver;
    String existingUser;

    @BeforeClass
    public void setup(ITestContext context){
        String path = System.getProperty("user.dir");
        System.out.println(path);
        System.setProperty("webdriver.chrome.driver", path+"\\src\\main\\resources\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://etherscan.io/register");
        driver.manage().window().maximize();
        context.setAttribute("WebDriver", driver);
    }

    @DataProvider
    public Object[][] invalidUsername(){

        return new Object[][]{
                {"test", true}, //<5 Chars
                {"test123456test123456test1234561", false}, //>31 Chars
                {"test@$",true} //Special Characters
        };
    }

    @Test(priority=1, dataProvider = "invalidUsername")
    public void test_InvalidUserName(String username, boolean isErrorExpected) {

        Assert.assertTrue(false,"");
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.clearUsername();
        registerPage.setUsername(username);
        Assert.assertEquals(registerPage.verifyErrUsernamePresent(), isErrorExpected, "FAILED || Error Message presence not validated");
        if(isErrorExpected)
            Assert.assertEquals(registerPage.getErrUsername(), "Username is invalid.", "FAILED || Error Message not validated");
    }

    @Test(priority=2)
    public void test_InvalidEmailAddress() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.clearEmail();
        registerPage.setEmail("invalid");
        Assert.assertEquals(registerPage.verifyErrEmailAddressPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getErrEmailAddress(), "Please enter a valid email address.", "FAILED || Error Message not validated");
    }

    @Test(priority=3)
    public void test_InvalidPassword() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.clearPassword();
        registerPage.setPassword("test");  //Password less than 5 chars
        Assert.assertEquals(registerPage.verifyErrPasswordPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getErrPassword(), "Your password must be at least 5 characters long.", "FAILED || Error Message not validated");
    }

    @DataProvider
    public Object[][] passwordStrength(){
        return new Object[][]{
                {"12345", "Strength: Weak!"}, //<5 Chars
                {"test123", "Strength: Medium!"}, //>31 Chars
                {"Test@123TEST@","Strength: Strong!"} //Special Characters
        };
    }
    @Test(priority=4, dataProvider = "passwordStrength")
    public void test_PasswordStrengthMessage(String password, String strengthMessage) {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.clearPassword();
        registerPage.setPassword(password);  //Password less than 5 chars
        Assert.assertEquals(registerPage.verifyMsgPasswordStrengthPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getMsgPasswordStrength(), strengthMessage, "FAILED || Error Message not validated");
    }

    @Test(priority=5)
    public void test_InvalidConfirmPassword() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.clearPassword();
        registerPage.setPassword("test123");
        registerPage.clearConfirmPassword();
        registerPage.setConfirmPassword("test");  //Password less than 5 chars
        Assert.assertEquals(registerPage.verifyErrConfirmPasswordPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getErrConfirmPassword(), "Your password must be at least 5 characters long.", "FAILED || Error Message not validated");
    }

    @Test(priority=6)
    public void test_differentConfirmPassword() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.clearPassword();
        registerPage.setPassword("test123");
        registerPage.clearConfirmPassword();
        registerPage.setConfirmPassword("testDiff");  //Password different
        Assert.assertEquals(registerPage.verifyErrConfirmPasswordPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getErrConfirmPassword(), "Password does not match, please check again.", "FAILED || Error Message not validated");
    }

    @Test(priority=7)
    public void test_TermsNotAccepted() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.uncheckTermsAndConditions();
        registerPage.clickRegisterButton();
        Assert.assertEquals(registerPage.verifyErrTermsAndConditionsPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getErrTermsAndConditions(), "Please accept our Terms and Conditions.", "FAILED || Error Message not validated");
    }

    /*//Run Without CAPTCHA
    @Test(priority=3)
    public void test_SubscriptionNotSelected() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.setUsername("TestUser");
        registerPage.setEmail("TestUser@Test.coma");
        registerPage.setPassword("Test123");
        registerPage.setConfirmPassword("Test123");
        registerPage.checkSubscription();
        registerPage.uncheckSubscription();
        registerPage.clickRegisterButton();
        Assert.assertEquals(registerPage.verifyMsgSuccessRegistrationPresent(), true, "FAILED || Success Message presence not validated");
        Assert.assertEquals(registerPage.getMsgSuccessRegistration(), "Successfully", "FAILED || Success Message presence not validated");
    }*/

    @Test(priority=3)
    public void test_CaptchaNotVerified() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.setUsername("TestUser");
        registerPage.setEmail("TestUser@Test.coma");
        registerPage.setPassword("Test123");
        registerPage.setConfirmPassword("Test123");
        registerPage.checkTermsAndConditions();
        registerPage.clickRegisterButton();
        Assert.assertEquals(registerPage.verifyErrCaptchaPresent(), true, "FAILED || Error Message presence not validated");
        Assert.assertEquals(registerPage.getErrCaptcha(), "Error! Invalid captcha response.\n" +"Please Try Again", "FAILED || Error Message not validated");
    }

    /*//Run Without Captcha
    @Test(priority=100)
    public void test_RegisterUser() {

        RegisterPage registerPage = new RegisterPage(driver);

        Random randNumber = new Random();
        int number = randNumber.nextInt(10000);
        existingUser="TestUserName" + number;

        registerPage.setUsername(existingUser);
        registerPage.setEmail("Test" + number + "@test.com");
        registerPage.setPassword("Test123@@");
        registerPage.setConfirmPassword("Test123@@");
        registerPage.checkTermsAndConditions();
        registerPage.checkSubscription();
        registerPage.checkCaptcha();

        registerPage.clickRegisterButton();

        Assert.assertTrue(registerPage.verifyMsgSuccessRegistrationPresent(), "FAILED || Success Error Message is not present");
        Assert.assertEquals(registerPage.getMsgSuccessRegistration(), "", "FAILED || Success Error Message is not present");
    }

    //Run Without Captcha
    @Test(priority=101, dependsOnMethods = "test_RegisterUser")
    public void test_DuplicateUser() {

        RegisterPage registerPage = new RegisterPage(driver);

        Random randNumber = new Random();
        int number = randNumber.nextInt(10000);
        existingUser="TestUserName" + number;

        registerPage.setUsername(existingUser);
        registerPage.setEmail("Test" + number + "@test.com");
        registerPage.setPassword("Test123@@");
        registerPage.setConfirmPassword("Test123@@");
        registerPage.checkTermsAndConditions();
        registerPage.checkSubscription();
        registerPage.checkCaptcha();

        registerPage.clickRegisterButton();

        Assert.assertTrue(registerPage.verifyErrDuplicateUserPresent(), "FAILED || Success Error Message is not present");
        Assert.assertEquals(registerPage.getErrDuplicateUser(), "Sorry! The username you entered is already in use.", "FAILED || Success Error Message is not present");
    }*/

    @AfterClass
    public void cleanup(){
        new RegisterPage(driver).clearAllFields();
        if(driver!=null) {
            driver.quit();
        }
    }
}
