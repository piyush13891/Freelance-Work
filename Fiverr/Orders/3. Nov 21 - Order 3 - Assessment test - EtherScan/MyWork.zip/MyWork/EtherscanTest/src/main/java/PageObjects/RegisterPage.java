package PageObjects;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegisterPage {

    WebDriver driver;

    public RegisterPage(WebDriver driver) {
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id="ContentPlaceHolder1_txtUserName")
    WebElement txtUsername;

    @FindBy(id="ContentPlaceHolder1_txtEmail")
    WebElement txtEmailAddress;

    @FindBy(id="ContentPlaceHolder1_txtPassword")
    WebElement txtPassword;

    @FindBy(id="ContentPlaceHolder1_txtPassword2")
    WebElement txtConfirmPassword;

    @FindBy(id="ContentPlaceHolder1_MyCheckBox")
    WebElement chkTermsAndConditions;

    @FindBy(id="ContentPlaceHolder1_SubscribeNewsletter")
    WebElement chkSubscribeLetter;

    @FindBy(xpath="//*[@id=\"recaptcha-anchor\"]/div[1]")
    WebElement chkCaptcha;

    @FindBy(id="ContentPlaceHolder1_btnRegister")
    WebElement btnRegister;


    @FindBy(id="ContentPlaceHolder1_txtUserName-error")
    WebElement errUsername;

    @FindBy(id="ContentPlaceHolder1_txtEmail-error")
    WebElement errEmailAddress;

    @FindBy(id="ContentPlaceHolder1_txtPassword-error")
    WebElement errPassword;

    @FindBy(id="ContentPlaceHolder1_txtPassword2-error")
    WebElement errConfirmPassword;

    @FindBy(id="ctl00$ContentPlaceHolder1$MyCheckBox-error")
    WebElement errTermsAndConditions;

    @FindBy(xpath="//*[@id=\"ctl00\"]/div[4]")
    WebElement errCaptcha;

    @FindBy(xpath="//*[@id=\"ctl00\"]/div[4]")
    WebElement msgSuccessRegistration;

    @FindBy(xpath="//*[@id=\"passstrength\"]/span")
    WebElement msgPasswordStrength;

    @FindBy(xpath="//*[@id=\"ctl00\"]/div[4]")
    WebElement errDuplicateUser;

    /**
     * Clean and Set Methods
     * @return
     */

    public void setUsername(String strUsername) {
        clearUsername();
        txtUsername.sendKeys(strUsername);
    }

    public void clearUsername() {
        txtUsername.clear();
    }

    public void setEmail(String strEmail) {
        clearEmail();
        txtEmailAddress.sendKeys(strEmail);
    }

    public void clearEmail() {
        txtEmailAddress.clear();
    }

    public void setPassword(String strPassword) {
        clearPassword();
        txtPassword.sendKeys(strPassword);
    }

    public void clearPassword() {
        txtPassword.clear();
    }

    public void setConfirmPassword(String strPassword) {
        clearConfirmPassword();
        txtConfirmPassword.sendKeys(strPassword);
    }

    public void clearConfirmPassword() {
        txtConfirmPassword.clear();
    }

    public void checkTermsAndConditions() {

        if (!chkTermsAndConditions.isSelected()) {
            Actions actions = new Actions(driver);
            actions.moveToElement(chkTermsAndConditions).click().build().perform();
        }
    }

    public void uncheckTermsAndConditions() {
        if (chkTermsAndConditions.isSelected()) {
            Actions actions = new Actions(driver);
            actions.moveToElement(chkTermsAndConditions).click().build().perform();
        }
    }

    public void checkSubscription() {
        if (!chkSubscribeLetter.isSelected()){
            Actions actions = new Actions(driver);
            actions.moveToElement(chkSubscribeLetter).click().build().perform();
        }
    }

    public void uncheckSubscription() {
        if (chkSubscribeLetter.isSelected()){
            Actions actions = new Actions(driver);
            actions.moveToElement(chkSubscribeLetter).click().build().perform();
        }
    }

    public void checkCaptcha() {
        driver.switchTo().frame(0);
        if (!chkCaptcha.isSelected()){
            Actions actions = new Actions(driver);
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", chkCaptcha);
            actions.moveToElement(chkCaptcha).click().build().perform();
        }
        driver.switchTo().defaultContent();
    }

    public void clickRegisterButton() {
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", btnRegister);
        btnRegister.click();
    }

    public void clearAllFields() {
        clearUsername();
        clearEmail();
        clearPassword();
        clearConfirmPassword();
        uncheckTermsAndConditions();
        uncheckSubscription();
    }

    /**
     * Verify Error Methods
     * @return
     */
    public boolean verifyErrUsernamePresent() {
        return errUsername.isDisplayed();
    }

    public boolean verifyErrEmailAddressPresent() {
        return errEmailAddress.isDisplayed();
    }

    public boolean verifyErrPasswordPresent() {
        return errPassword.isDisplayed();
    }

    public boolean verifyErrConfirmPasswordPresent() {
        return errConfirmPassword.isDisplayed();
    }

    public boolean verifyErrTermsAndConditionsPresent() {
        return errTermsAndConditions.isDisplayed();
    }

    public boolean verifyErrCaptchaPresent() {
        return errCaptcha.isDisplayed();
    }

    public boolean verifyMsgSuccessRegistrationPresent() {
        return msgSuccessRegistration.isDisplayed();
    }

    public boolean verifyMsgPasswordStrengthPresent() {
        return msgPasswordStrength.isDisplayed();
    }

    public boolean verifyErrDuplicateUserPresent() {
        return errDuplicateUser.isDisplayed();
    }

    /**
     * Get Error Methods
     * @return
     */
    public String getErrUsername() {
        return errUsername.getText();
    }

    public String getErrEmailAddress() {
        return errEmailAddress.getText();
    }

    public String getErrPassword() {
        return errPassword.getText();
    }

    public String getErrConfirmPassword() {
        return errConfirmPassword.getText();
    }

    public String getErrTermsAndConditions() {
        return errTermsAndConditions.getText();
    }

    public String getErrCaptcha() {
        return errCaptcha.getText();
    }

    public String getMsgSuccessRegistration() {
        return msgSuccessRegistration.getText();
    }

    public String getMsgPasswordStrength() {
        return msgPasswordStrength.getText();
    }

    public String getErrDuplicateUser() {
        return errDuplicateUser.getText();
    }



    public void hardWait(){
        try{
        Thread.sleep(3000);
        }
        catch (Exception e){

        }
    }
}
