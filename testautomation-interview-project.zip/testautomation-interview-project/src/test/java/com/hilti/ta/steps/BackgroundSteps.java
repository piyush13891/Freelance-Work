package com.hilti.ta.steps;

import com.hilti.ta.utils.WebDriverFactory;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Cucumber hook steps definition class responsible for actions taken before and after test execution.
 */
public class BackgroundSteps {

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss.SSS");

	@Before
	public void beforeUITests(final Scenario scenario) {
		scenario.write("Start Time: " + dateFormat.format(new Date()));
		WebDriverFactory.initialize();
	}

	@After
	public void afterUITests(final Scenario scenario) {
		if (!scenario.isFailed()) {
			WebDriverFactory.quitCurrentDriver();
		}
		scenario.write("End Time: " + dateFormat.format(new Date()));
	}
}
