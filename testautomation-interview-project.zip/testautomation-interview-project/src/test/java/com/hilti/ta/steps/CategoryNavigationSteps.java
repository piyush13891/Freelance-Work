package com.hilti.ta.steps;

import com.hilti.ta.pages.CategoryPage;
import com.hilti.ta.pages.components.HeaderComponent;
import com.hilti.ta.utils.WebDriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * Cucumber steps definition class related to Product Navigation functionality.
 */
public class CategoryNavigationSteps {

	private final CategoryPage categoryPage = new CategoryPage();

	@When("User navigates to category page for {}")
	public void userNavigatesToCategoryPage(final String categoryName) {
		System.out.println("aa" +categoryName);
		WebDriverFactory.getDriver().navigate().to(WebDriverFactory.getDriver().getCurrentUrl() + "c" + categoryName);
	}

	@Then("User can see different performance level products on category page")
	public void verifyDifferentPerformanceLevelProductsOnCategoryPage() {
		System.out.println("bb");
		categoryPage.verifyAtLeaseOneProductForEachCategoryPresent();
	}

	@When("User selects performance level {} in the filters")
	public void selectsPerformanceLevelInFilters(final String performanceLevel) {
		System.out.println("cc" + performanceLevel);
		categoryPage.filterByCategory(performanceLevel);
	}

	@Then("User can see only {} performance level products on category page")
	public void verifyProductsForPerformanceLevelFilter(final String performanceLevel) {
		System.out.println("dd" + performanceLevel);
	}

	@When("User resets the performance level filter")
	public void ResetsPerformanceLevelFilter() {
		System.out.println("ee");
		categoryPage.filterByCategory("No performence");
	}

}
