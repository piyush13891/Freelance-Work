package com.hilti.ta.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.hilti.ta.utils.WebDriverFactory;

import java.awt.*;

public abstract class PageObject {

    protected boolean isElementVisible(final By locator) {
        try {
            final WebElement consentBanner = WebDriverFactory.getWebDriverWait(2).until(ExpectedConditions.presenceOfElementLocated(locator));
            return consentBanner.isDisplayed();
        } catch (final TimeoutException e) {
            // Element not found
            return false;
        }
    }

    protected static void scrollElementInView(final WebDriver webDriver, By elementLocator) {

        WebElement element = webDriver.findElement(elementLocator);
        Actions actions = new Actions(webDriver);

        int x = (int)(element.getLocation().getY() / Toolkit.getDefaultToolkit().getScreenSize().getHeight());

        if(x>0){
            actions.moveToElement(element).sendKeys(Keys.PAGE_DOWN).
                    sendKeys(Keys.UP).sendKeys(Keys.UP).
                    sendKeys(Keys.UP).sendKeys(Keys.UP).sendKeys(Keys.UP).
                    perform();
        }
        //webDriver.findElement(By.id("tab-button-tab-shop")).getLocation()
        Toolkit.getDefaultToolkit().getScreenSize().getWidth();
    }

}
