package com.hilti.ta.pages;

/**
 * Page Object Model representing Firestops page.
 */
public class FirestopsPage extends PageObject {
}
