package com.hilti.ta.pages;

import com.hilti.ta.utils.WebDriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import java.util.List;

/**
 * Page Object Model representing Product Category Page.
 */
public class CategoryPage extends PageObject {

    private static final By ultimateProducts = By.cssSelector(".flex-nowrap.bl-h-3.indicator-label-ultimate");
    private static final By premiumProducts = By.cssSelector(".flex-nowrap.bl-h-3.indicator-label-premium");
    private static final By standardProducts = By.cssSelector(".flex-nowrap.bl-h-3.indicator-label-standard");

    private static final By productCategoryClassFilterUltimate= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Ultimate')]");
    private static final By productCategoryClassFilterPremium= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Premium')]");
    private static final By productCategoryClassFilterStandard= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Standard')]");
    private static final By productCategoryClassFilterNoPreference= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Premium')]/parent::button/parent::shrd-uic-form-button/preceding-sibling::shrd-uic-form-button/button/span[contains(text(),'No preference')]");

    private static final By productItemsList = By.className(".ng-grid-item");

    public int getCountOfItemsForCategoryOnPage(final String category) {
       // WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productNavigationMenuItem));
        int size = 0;
        switch(category.toUpperCase()) {
            case "ULTIMATE":
                size = WebDriverFactory.getDriver().findElements(ultimateProducts).size();
                break;
            case "PREMIUM":
                size = WebDriverFactory.getDriver().findElements(premiumProducts).size();
                break;
            case "STANDARD":
                size = WebDriverFactory.getDriver().findElements(standardProducts).size();
                break;
        }
        return size;
    }

    public void verifyAtLeaseOneProductForEachCategoryPresent() {
        Assert.assertTrue(getCountOfItemsForCategoryOnPage("ultimate") > 0, "FAILED | No Ultimate Products found on Page");
        Assert.assertTrue(getCountOfItemsForCategoryOnPage("premium") > 0, "FAILED | No Premium Products found on Page");
        Assert.assertTrue(getCountOfItemsForCategoryOnPage("standard") > 0, "FAILED | No Standard Products found on Page");
    }

    public int filterByCategory(final String category) {
        // WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productNavigationMenuItem));
        int size = 0;
        switch(category.toUpperCase()) {
            case "ULTIMATE":
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterUltimate);
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterUltimate).click();
                break;
            case "PREMIUM":
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterPremium).click();
                break;
            case "STANDARD":
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterStandard).click();
                break;
            case "NO PREFERENCE":
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterNoPreference).click();
                break;
        }
        return size;
    }

    public void verifyAllProductsForCategory(String category) {

        List<WebElement> productItems = WebDriverFactory.getDriver().findElements(productItemsList);

        for(WebElement item: productItems){



        }
    }

}
