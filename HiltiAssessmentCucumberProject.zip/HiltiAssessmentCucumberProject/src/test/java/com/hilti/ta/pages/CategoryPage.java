package com.hilti.ta.pages;

import com.hilti.ta.pages.components.ConsentsComponent;
import com.hilti.ta.utils.PerformanceLevels;
import com.hilti.ta.utils.WebDriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Page Object Model representing Product Category Page.
 */
public class CategoryPage extends PageObject {

    private final com.hilti.ta.pages.components.ConsentsComponent consentsComponent = new ConsentsComponent();
    private static final By productPerformanceClassFilterUltimate = By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Ultimate')]/parent::button");
    private static final By productPerformanceClassFilterPremium = By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Premium')]/parent::button");
    private static final By productPerformanceClassFilterStandard = By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Standard')]/parent::button");
    private static final By productPerformanceClassFilterNoPreference = By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Premium')]/parent::button/parent::shrd-uic-form-button/parent::div/shrd-uic-form-button/button");
    private static final By allProductItemsNoPreferencesList = By.cssSelector("div[class*='indicator-label d-flex flex-row flex-nowrap bl-h-3 indicator-label-']");

    /**
     * Navigate to Category page
     * @param categoryPath path to Category
     */
    public void navigateToCategoryPage(final String categoryPath){
        WebDriverFactory.getDriver().navigate().to(WebDriverFactory.getDriver().getCurrentUrl() + "c" + categoryPath);
        consentsComponent.closeOtherBanners();
    }

    /**
     * Get count of item for a performanceLevel on page
     * @param performanceLevel
     * @return count of items
     */
    public int getCountOfItemsForPerformanceLevelOnPage(final String performanceLevel) {

        int size;
        List<WebElement> elements = WebDriverFactory.getDriver().findElements(allProductItemsNoPreferencesList);

        switch(performanceLevel.toUpperCase()) {
            case "ULTIMATE":
            case "PREMIUM":
            case "STANDARD":
                size = elements.stream().filter(x->x.getAttribute("class").
                        contains(performanceLevel.toLowerCase())).collect(Collectors.toList()).size();
                break;
            default:
                size = WebDriverFactory.getDriver().findElements(allProductItemsNoPreferencesList).size();
                break;
        }
        return size;
    }

    /**
     * Verify that at least one product is present on page for each performance level
     */
    public void verifyAtLeastOneProductForEachPerformanceLevelPresent() {
        Assert.assertTrue(getCountOfItemsForPerformanceLevelOnPage(PerformanceLevels.ULTIMATE.getPerformanceLevel()) > 0, "FAILED | No Ultimate Products found on Page");
        Assert.assertTrue(getCountOfItemsForPerformanceLevelOnPage(PerformanceLevels.PREMIUM.getPerformanceLevel()) > 0, "FAILED | No Premium Products found on Page");
        Assert.assertTrue(getCountOfItemsForPerformanceLevelOnPage(PerformanceLevels.STANDARD.getPerformanceLevel()) > 0, "FAILED | No Standard Products found on Page");
    }

    /**
     * Apply/select filter for performanceLevel
     * @param performanceLevel
     */
    public void filterByPerformanceLevel(final String performanceLevel) {

        switch(performanceLevel.toUpperCase()) {
            case "ULTIMATE":
                applyPerformanceLevelFilter(performanceLevel, productPerformanceClassFilterUltimate);
                break;
            case "PREMIUM":
                applyPerformanceLevelFilter(performanceLevel, productPerformanceClassFilterPremium);
                break;
            case "STANDARD":
                applyPerformanceLevelFilter(performanceLevel, productPerformanceClassFilterStandard);
                break;
            case "NO PREFERENCE":
                applyPerformanceLevelFilter(performanceLevel, productPerformanceClassFilterNoPreference);
                break;
        }
    }

    /**
     * Apply Performance filter for the performanceLevel and verify if filter is applied correctly
     * @param performanceLevel
     * @param performanceFilter filter element
     */
    public void applyPerformanceLevelFilter(final String performanceLevel, final By performanceFilter) {

        int count = getCountOfItemsForPerformanceLevelOnPage(PerformanceLevels.NO_PREFERENCE.getPerformanceLevel());
        int countLevel = getCountOfItemsForPerformanceLevelOnPage(performanceLevel);

        scrollElementInView(WebDriverFactory.getDriver(), performanceFilter);
        waitForElementToBeClickableAndVisible(performanceFilter);
        WebDriverFactory.getDriver().findElement(performanceFilter).click();

        int retry=0;
        while(!WebDriverFactory.getDriver().findElement(performanceFilter).findElement(By.xpath(".//span")).getAttribute("class").contains("is-checked") && retry<3)
        {
            WebDriverFactory.getDriver().findElement(performanceFilter).click();
            retry++;
        }

        if(!performanceLevel.equalsIgnoreCase(PerformanceLevels.NO_PREFERENCE.getPerformanceLevel())){
            WebDriverFactory.getWebDriverWait().until(ExpectedConditions.and(
                    ExpectedConditions.numberOfElementsToBeLessThan(allProductItemsNoPreferencesList, count),
                    ExpectedConditions.numberOfElementsToBe(allProductItemsNoPreferencesList, countLevel)
            ));
        }
        else{
            WebDriverFactory.getWebDriverWait().until(ExpectedConditions.numberOfElementsToBeMoreThan(
                    allProductItemsNoPreferencesList, count)
            );
        }
    }

    /**
     * Verify that all products are of Performance Level
     * @param performanceLevel
     */
    public void verifyAllProductsForPerformanceLevel(final String performanceLevel) {

        List<WebElement> allProducts = WebDriverFactory.getDriver().findElements(allProductItemsNoPreferencesList);

        for(WebElement item : allProducts){
            Assert.assertEquals(item.getText().toUpperCase(), performanceLevel.toUpperCase(), "FAILED | Found product with Preference other than :: " + performanceLevel);
        }

        Assert.assertTrue(getCountOfItemsForPerformanceLevelOnPage(performanceLevel) > 0, "FAILED | No Products found on Page for performanceLevel :: " + performanceLevel);
    }
}
