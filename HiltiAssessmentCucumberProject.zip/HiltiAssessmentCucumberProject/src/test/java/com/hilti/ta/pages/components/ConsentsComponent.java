package com.hilti.ta.pages.components;

import org.openqa.selenium.By;
import com.hilti.ta.pages.PageObject;
import com.hilti.ta.utils.WebDriverFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

/**
 * Page Object Model representing Legal Consents Banner and Popup.
 */
public class ConsentsComponent extends PageObject {

    private final By consentBanner = By.xpath("//div[contains(@id,'didomi')][1]//div[contains(@class,'notice__')]");
    private final By acceptCookieSettingsButton = By.xpath("//div[@id='didomi-custom-host']//a[contains(@class, 'a-button-primary accept_button')]");
    private final By cookieSettings = By.xpath("//div[contains(@id,'didomi')][1]//div[contains(@id,'didomi')]");
    private final By denyButton = By.xpath("(//div[contains(@id,'didomi')][1]//div[contains(@class,'bottom_')]//a)[last()-1]");
    private final By consentBannerUSA = By.className("js-prevent-tooltip-closing");
    private final By closeOtherBanners = By.xpath("//div[@class='m-smartbar-content']//a[contains(@class, 'js-banner-close-forever')]");
    /**
     * Closes consents banner or popup.
     */
    public void closeConsents(final String country) {
        if (isConsentsBannerVisible()) {
            clickAcceptCookieSettingsButton();
        } else if (areCookieSettingsVisible()) {
            clickDenyButton();
        }

        switch(country) {
            case "United States":
                if (isElementVisible(consentBannerUSA))
                    clickAcceptAllButton();
                break;
        }
    }


    private boolean isConsentsBannerVisible() {
        return isElementVisible(consentBanner);
    }

    public void clickAcceptCookieSettingsButton() {
        WebDriverFactory.getDriver().findElement(acceptCookieSettingsButton).click();
    }

    public boolean areCookieSettingsVisible() {
        return isElementVisible(cookieSettings);
    }

    public void clickDenyButton() {
        WebDriverFactory.getDriver().findElement(denyButton).click();
    }

    public void clickAcceptAllButton() {
        WebDriverFactory.getDriver().findElement(consentBannerUSA).click();
    }

    public void closeOtherBanners() {
        if (isElementVisible(closeOtherBanners)) {
            WebDriverFactory.getDriver().findElement(closeOtherBanners).click();
            WebDriverFactory.getWebDriverWait().until(ExpectedConditions.invisibilityOfElementLocated(closeOtherBanners));
        }
    }
}
