package com.hilti.ta.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.hilti.ta.utils.WebDriverFactory;

import java.time.Duration;


public abstract class PageObject {

    protected boolean isElementVisible(final By locator) {
        try {
            final WebElement consentBanner = WebDriverFactory.getWebDriverWait(5).until(ExpectedConditions.visibilityOfElementLocated(locator));
            return consentBanner.isDisplayed();
        } catch (final TimeoutException e) {
            // Element not found
            return false;
        }
    }

    protected void waitForElementToBeClickableAndVisible(final By locator) {

        WebDriverFactory.getWebDriverWait().until(ExpectedConditions.and(
                ExpectedConditions.visibilityOfElementLocated(locator),
                ExpectedConditions.elementToBeClickable(locator)
        ));
    }

    protected static void scrollElementInView(final WebDriver webDriver, By elementLocator) {

        WebElement element = webDriver.findElement(elementLocator);
        Actions actions = new Actions(webDriver);

        try{
            actions.moveToElement(element).perform();
            element.click();
        }catch(ElementClickInterceptedException ex){
            actions.moveToElement(element).
                    sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).click().
                    perform();
        }
    }
}
