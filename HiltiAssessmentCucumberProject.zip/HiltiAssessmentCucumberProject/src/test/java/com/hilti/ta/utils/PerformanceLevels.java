package com.hilti.ta.utils;

/**
 * Enumeration class containing Preferences Filter Options supported by HILTI website.
 */
public enum PerformanceLevels {
	ULTIMATE("ultimate"),
	PREMIUM("Premium"),
	STANDARD("Standard"),
	NO_PREFERENCE("No preference");

	private String preferenceName;

	PerformanceLevels(final String preferenceName) {
		this.preferenceName = preferenceName;
	}

	public String getPerformanceLevel() {
		return preferenceName;
	}
}
