package com.hilti.ta.steps;

import com.hilti.ta.pages.CategoryPage;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * Cucumber steps definition class related to Performance Filters functionality.
 */
public class PerformanceFilterSteps {

	private final CategoryPage categoryPage = new CategoryPage();

	@When("User navigates to category page for {}")
	public void userNavigatesToCategoryPage(final String categoryName) {
		categoryPage.navigateToCategoryPage(categoryName);
	}

	@Then("User can see different performance level products on category page")
	public void verifyDifferentPerformanceLevelProductsOnCategoryPage() {
		categoryPage.verifyAtLeastOneProductForEachPerformanceLevelPresent();
	}

	@When("User selects performance level {} in the filters")
	public void selectsPerformanceLevelInFilters(final String performanceLevel) throws InterruptedException {
		categoryPage.filterByPerformanceLevel(performanceLevel);
	}

	@Then("User can see only {} performance level products on category page")
	public void verifyProductsForPerformanceLevelFilter(final String performanceLevel) {
		categoryPage.verifyAllProductsForPerformanceLevel(performanceLevel);
	}

	@When("User resets the performance level filter")
	public void ResetsPerformanceLevelFilter() {
		categoryPage.filterByPerformanceLevel("No preference");
		categoryPage.verifyAtLeastOneProductForEachPerformanceLevelPresent();
	}

}
