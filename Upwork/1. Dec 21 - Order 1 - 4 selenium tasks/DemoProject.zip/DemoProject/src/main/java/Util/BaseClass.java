package Util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import java.time.Duration;

/**
 * This is Base class for Common Test Setup
 */
public class BaseClass {

    public static WebDriver driver;

    /**
     * To Initialize browser setting before test runs
     */
    @BeforeMethod(alwaysRun = true)
    public void setup(ITestContext context){
        String path = System.getProperty("user.dir");
        System.setProperty("webdriver.chrome.driver", path + "\\src\\main\\resources\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://qa-challenge.codesubmit.io");
        driver.manage().window().maximize();
        context.setAttribute("WebDriver", driver);
    }

    /**
     * To Close browser after test finished
     */
    @AfterMethod(alwaysRun = true)
    public void tearDown(){
        driver.quit();
    }
}
