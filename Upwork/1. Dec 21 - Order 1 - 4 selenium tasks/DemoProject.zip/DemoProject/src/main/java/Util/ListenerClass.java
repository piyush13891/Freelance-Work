package Util;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * This is Listener class to listen events like test start, failed and take screenshot
 */
public class ListenerClass  implements ITestListener {

    @Override
    public void onFinish(ITestContext arg0) {   }

    @Override
    public void onStart(ITestContext arg0) {  }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {  }

    @Override
    public void onTestSkipped(ITestResult arg0) {   }

    @Override
    public void onTestStart(ITestResult arg0) {   }

    @Override
    public void onTestSuccess(ITestResult arg0) {   }

    /**
     * Capture screenshot on failure
     */
    @Override
    public void onTestFailure(ITestResult result) {
        String methodName =  result.getName().toString().trim();
        ITestContext context = result.getTestContext();
        WebDriver driver = (WebDriver)context.getAttribute("WebDriver");
        takeScreenshot(methodName, driver);
    }

    /**
     * Method to capture screenshot
     */
    public void takeScreenshot(String methodName, WebDriver driver){

        TakesScreenshot ts = (TakesScreenshot)driver;
        File srcFile = ts.getScreenshotAs(OutputType.FILE);
        String path  = System.getProperty("user.dir");

        try {
            FileUtils.copyFile(srcFile, new File(path + "\\src\\SCREENSHOTS\\" + methodName+ "BugError.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}