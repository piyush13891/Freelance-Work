package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Page Object for Cart Page
 */
public class CartPage {

    WebDriver driver;

    public CartPage(WebDriver driver){
        this.driver =  driver;
        PageFactory.initElements(driver, this); // To Initialize Page elements
    }

    /**
     * Page Elements
     */
    @FindBy(className = "inventory_item_price")
    WebElement cartProductPrice;

    @FindBy(className = "btn_small")
    WebElement removeItem;

    /**
     * Get Price in Cart
     */
    public String getProductPrice(){
        return cartProductPrice.getText();
    }

    /**
     *Remove Product from Cart
     */
    public void clickRemove(){
        removeItem.click();
    }

}
