package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * Page Object for Login Page
 */
public class LoginPage {

    WebDriver driver;

    public LoginPage(WebDriver driver){
        this.driver =  driver;
        PageFactory.initElements(driver, this); // To Initialize Page elements
    }

    /**
     * Page Elements
      */
    @FindBy(id = "user-name")
    WebElement txtUsername;

    @FindBy(id = "password")
    WebElement txtPassword;

    @FindBy(id = "login-button")
    WebElement btnLogin;

    @FindBy(xpath = "//*[@id=\"login_button_container\"]/div/form/div[3]/h3")
    WebElement errorMessage;

    /**
     * Enter Username
     */
    public void setUserName(String username){
        txtUsername.clear();
        txtUsername.sendKeys(username);
    }

    /**
     * Enter Password
     */
    public void setPassword(String password){
        txtPassword.clear();
        txtPassword.sendKeys(password);
    }

    /**
     * Click login button
     */
    public void clickLoginButton(){
        btnLogin.click();
    }

    /**
     * Get error message for login
     */
    public String getErrorMessage(){
       return  errorMessage.getText();
    }

}
