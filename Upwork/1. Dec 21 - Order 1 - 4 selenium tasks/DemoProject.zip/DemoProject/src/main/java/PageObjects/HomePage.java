package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Page Object for Home Page
 */
public class HomePage {

    WebDriver driver;

    public HomePage(WebDriver driver){
        this.driver =  driver;
        PageFactory.initElements(driver, this); // To Initialize Page elements
    }

    /**
     * Page Elements
     */
    @FindBy(className = "title")
    WebElement pageTitle;

    @FindBy(xpath = "//*[@id=\"item_4_img_link\"]/img")
    WebElement imageSource;

    @FindBy(xpath = "//*[@id=\"inventory_item_container\"]/div/div/div[1]/img")
    WebElement imageSourceProductDetail;

    @FindBy(className = "btn_small")
    WebElement addToCart;

    @FindBy(xpath = "//*[@id=\"shopping_cart_container\"]/a")
    WebElement cartLink;

    @FindBy(className = "inventory_details_price")
    WebElement price;

    /**
     * Get Page Title
     */
    public String getPageTitle(){
       return pageTitle.getText();
    }

    /**
     * Get Image source of product
     */
    public String getImageSource(){
        return imageSource.getAttribute("src");
    }

    /**
     * Click on product image
     */
    public void clickProductImage(){
        imageSource.click();;
    }

    /**
     * Get Image Source on detail page
     */
    public String getImageSourceProductDetail(){
        return imageSourceProductDetail.getAttribute("src");
    }

    /**
     * Add product to cart
     */
    public void clickAddToCart(){
        addToCart.click();
    }

    /**
     * Go to cart
     */
    public void clickAndGoToCart(){
        cartLink.click();
    }

    /**
     * get product price
     */
    public String getPrice(){
        return price.getText();
    }

}
