import PageObjects.CartPage;
import PageObjects.HomePage;
import PageObjects.LoginPage;
import Util.BaseClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests extends BaseClass {

    public LoginTests(){
        super();
    }

    /**
     * Test to validate Standard user login
     */
    @Test( groups = {"sanity"} , priority = 0)
    public void loginWithStandard_user() {

        HomePage homePage = new HomePage(driver);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUserName("standard_user");
        loginPage.setPassword("secret_sauce");
        loginPage.clickLoginButton();

        Assert.assertEquals(homePage.getPageTitle(), "PRODUCTS", "Not Correct page");
        String imageSourceBefore = homePage.getImageSource();
        homePage.clickProductImage();
        Assert.assertEquals(imageSourceBefore, homePage.getImageSourceProductDetail(), "Expected images to be same");
    }

    /**
     * Test to validate error for locked out user
     */
    @Test( groups = {"sanity"}, priority = 1)
    public void loginWithLockedOut_user() {

        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUserName("locked_out_user");
        loginPage.setPassword("secret_sauce");
        loginPage.clickLoginButton();

        Assert.assertEquals(loginPage.getErrorMessage(),
                "Epic sadface: Sorry, this user has been locked out.", "Error not displayed");
    }

    /**
     * Test to validate Problem user site
     */
    @Test( groups = {"sanity"}, priority = 2 )
    public void loginWithProblem_user() {

        HomePage homePage = new HomePage(driver);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUserName("problem_user");
        loginPage.setPassword("secret_sauce");
        loginPage.clickLoginButton();

        Assert.assertEquals(homePage.getPageTitle(), "PRODUCTS", "Not Correct page");
        String imageSourceBefore = homePage.getImageSource();
        homePage.clickProductImage();
        Assert.assertNotEquals(imageSourceBefore,
                homePage.getImageSourceProductDetail(), "Expected images to be different");
    }

    /**
     * Test to validate product checkout
     */
    @Test( groups = {"sanity"}, priority = 3 )
    public void productCheckoutTest(){

        HomePage homePage =  new HomePage(driver);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.setUserName("standard_user");
        loginPage.setPassword("secret_sauce");
        loginPage.clickLoginButton();

        Assert.assertEquals(homePage.getPageTitle(), "PRODUCTS", "Not Correct page");
        String imageSourceBefore = homePage.getImageSource();
        homePage.clickProductImage();
        Assert.assertEquals(imageSourceBefore, homePage.getImageSourceProductDetail(), "Expected images to be same");

        String productPrice =  homePage.getPrice();
        homePage.clickAddToCart();
        homePage.clickAndGoToCart();

        CartPage cartPage =  new CartPage(driver);
        Assert.assertEquals(productPrice, cartPage.getProductPrice(), "Product Price Not Validated");
        cartPage.clickRemove();
    }
}
