package com.course542.flipkart.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.CartPage;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;
import com.course542.flipkart.pages.ProductPage;
import com.course542.flipkart.pages.SearchPage;
import com.course542.flipkart.util.TestUtil;


public class CartPageTest extends Driver{
	
	LoginPage loginPage;
	Homepage homepage;
	SearchPage searchpage;
	ProductPage productpage;
	CartPage cart;	
	WebElement firstItem;
	String prodName;
	String price;
	
	public static Logger log=LogManager.getLogger(CartPageTest.class.getName());

	public CartPageTest() {
		super();
	}

	@BeforeMethod
	public void setUp(ITestContext context) throws Exception {
		
		log.info("======Starting CartPage Test========");
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded!");
		
		context.setAttribute("WebDriver", driver);
		
		loginPage=new LoginPage();
		homepage=loginPage.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));	
		
		try{
			//homepage=loginPage.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
			if(homepage!=null) {
				log.info("Successfully Logged in! Loading to homepage.");
			}
		}catch(Exception e) {
			log.error("Login failed!");
		}
		
		searchpage = homepage.Search(prop.getProperty("toSearch"));
		
		firstItem = searchpage.getFirstProduct();

		prodName = firstItem.findElement(By.xpath("a/div[2]/div/div")).getText();					
		price =  firstItem.findElement(By.xpath("a/div[2]/div[2]/div/div/div")).getText();

		
		productpage=searchpage.openFirstProduct();
		if(productpage!=null) {
			log.info("Traversed to product page");
		}
		else {
			throw new Exception("traversal to productpage failed!");
		}
		
		productpage.setPinCode("411027");
		cart=productpage.addProductToCart();
		if(cart!=null) {
			log.info("Traversed to cart page");
		}
		else {
			throw new Exception("traversal to cart failed!");
		}
	}

	@Test(priority=1)
	public void ScreenshotCartPage() throws Exception {
		if(cart.verifyCart()) {
			log.info("Taking Screenshot!");
			cart.takeCartScreenshot();
		}else {
			log.error("Not in cart Page! Not taking screenshot!");
			Assert.fail("Not in cart Page! Not taking screenshot!");
			throw new Exception("Not in cart Page! Not taking screenshot!");
		}
	}

	@Test(priority=2)
	public void removeFromCart() {
		
		if(cart.verifyCart()) {
			
			log.info("In cart Page:verified!");
			log.info("Cart size="+cart.returnCartSize());
			
			if(cart.returnCartSize()==1) {

				log.info("No.of products in cart=1");
				cart.clickRemove();
				log.info("Removed 1 product!");
				
				log.info("Verifying cart message!");				
				String msg=cart.CartMsg();
				
				log.info("Cart message="+msg);
				Assert.assertEquals(msg, prop.getProperty("emptyCartMsg"));
				log.info("Carts message matched!");
			}
			else if(cart.returnCartSize()>1) {
				log.info("No.of products in cart="+cart.returnCartSize());
				cart.clickRemove(1);
				log.info("Removed 1st product!");
			}
			else {
				log.error("Cart is empty");
				Assert.fail("Cart is Empty");
			}
		}
		else {
			log.error("Not in cart page!");
			Assert.fail("Not in cart page!");
		}
	}
	
	//Not Placing full Order - Also depends on saved details for user so test flow might change	
		@Test(priority=3)
		public void verifyCartDetails(){

			if(cart.verifyCart()) {
				
				log.info("In cart Page:verified!");
				log.info("Cart size=" + cart.returnCartSize());
				
				//log.info("Get Total Price");
				//String totalPrice = cart.getTotalPrice();
				
				if(cart.returnCartSize()>=1) {	
					log.info("Verify Price and Item Name");
					Assert.assertEquals(prodName, cart.getCartItemName(), "Price and totals are not same");					
					//Assert.assertEquals(totalPrice, cart.getCartItemPrice(), "Price and totals are not same");
					Assert.assertEquals(price, cart.getCartItemPrice(), "Price and totals are not same");					
				}
				else {
					log.error("Cart is empty");
					Assert.fail("Not in cart page!");
				}
			}
			else {
				log.error("Not in cart page!");
				Assert.fail("Not in cart page!");
			}
		}


	
	//Not Placing full Order - Also depends on saved details for user so test flow might change	
	@Test(priority=4)
	public void placeOrderTest(){
		
		if(cart.verifyCart()) {
			
			log.info("In cart Page:verified!");
			log.info("Cart size=" + cart.returnCartSize());
			
			if(cart.returnCartSize()>=1) {
					
				log.info("Place Order");
				cart.placeOrder();
				
				TestUtil.waitForSeconds(2);
				log.info("Remove Item");	
				cart.clickRemove();				
			}			
			else {
				log.error("Cart is empty");
				Assert.fail("Not in cart page!");
			}
		}
		else {
			log.error("Not in cart page!");
			Assert.fail("Not in cart page!");
		}
	}
	

	@Test(priority=5)
	public void logoutfromAppinCart() {
		log.info("Searching logout button!");
		cart.Logout();
		Assert.assertTrue(cart.verifyLogout());
		log.info("Logout Verified!");
	}


	@AfterMethod
	public void teardown() {
		log.info("Closing browser...");
		driver.quit();
		log.info("Browser closed!");
	}

}
