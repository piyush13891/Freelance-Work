package com.course542.flipkart.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;
import com.course542.flipkart.pages.SearchPage;
import com.course542.flipkart.util.TestUtil;

public class HomepageTest extends Driver {
	LoginPage login;
	Homepage homepage;
	SearchPage searchpage;
	public static Logger log=LogManager.getLogger(HomepageTest.class.getName());

	public HomepageTest() {
		super();
	}

	@BeforeTest
	public void setUp(ITestContext context) throws Exception {
				
		log.info("======Starting HomePage Test!=========");
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded! Traversing to LoginPage!");
		context.setAttribute("WebDriver", driver);
		
		login=new LoginPage();
		log.info("login page initialized");
		try{
			homepage=login.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
			if(homepage!=null) {
				log.info("Successfully Logged in! Loading to homepage.");
				}
			}catch(Exception e) {
				log.error("Login failed!");
			}
		TestUtil.waitForSeconds(3);
	}

	@Test(priority=1)
	public void verifyHomePageTitileTest() {
		
		homepage = new Homepage();
		
		log.info("verifying HomePageTitle");
		String title = homepage.getTitle();
		System.out.println("*********************************************");
		System.out.println("Title:"+title);
		log.info("Found homePageTitle->"+title);
		Assert.assertEquals(title,prop.getProperty("homePageTitle"));
		log.info("Title Verified!");
	}

	@Test(priority=2)
	public void verifyHomepageCorrectSignIn() {
		homepage = new Homepage();
		log.info("Verifying username");
		homepage.validateCorrectProfile();
	}		

	@Test(priority=3)
	public void verifyAllItemCategoriesHeader() {		
		homepage = new Homepage();
		log.info("Verifying Main Item Categories list at top");
		homepage.verifyItemCategoriesListHeader();
	}
	
	@DataProvider
	public Object[][] categoryTestData(){
		
		return new Object[][] {
			{ "Fashion", "Men's Top Wear" },
			{ "Electronics", "Electronics GST Store" },
			{ "Home", "Home Furnishings" },
			{ "Appliances", "Washing Machines" },
			{ "Beauty, Toys & More", "Beauty & Personal Care" }			
		};
	}
	
	
	@Test(priority=4, dataProvider = "categoryTestData")
	public void verifyItemSubcategories(String category, String subCategory) {	
		
		homepage = new Homepage();
		log.info("Verifying Main Item Categories list at top");
		homepage.verifyItemSubCategoriesFromTop(category, subCategory);					
	}	
	

	@AfterTest
	public void teardown() {
		log.info("Closing browser...");
		driver.quit();
		log.info("Browser closed!");
	}
}
