package com.course542.flipkart.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.CartPage;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;
import com.course542.flipkart.pages.ProductPage;
import com.course542.flipkart.pages.SearchPage;
import com.course542.flipkart.util.TestUtil;

public class ProductPageTest extends Driver {

	Homepage homepage;
	SearchPage searchpage;
	LoginPage loginPage;
	ProductPage productpage;
	CartPage cart;
	public static Logger log=LogManager.getLogger(ProductPageTest.class.getName());

	public ProductPageTest() {
		super();
	}


	@BeforeTest
	public void setUp(ITestContext context) throws Exception {
				
		log.info("======Starting ProductPage Test========");
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded Traversing to LoginPage!");
		context.setAttribute("WebDriver", driver);
		
		loginPage=new LoginPage();
		
		//homepage=loginPage.LoginToHome(prop.getProperty("email"),prop.getProperty("pass"));
		  
	  try{ 
		  homepage=loginPage.LoginToHome(prop.getProperty("email"),prop.getProperty("pass"));
				  	
	  if(homepage!=null) {
		  log.info("Successfully Logged in! Loading to homepage."); 
		  }
	  }catch(Exception e) { log.error("Login failed!"); }			 
		
		searchpage = homepage.Search(prop.getProperty("toSearch"));
		if(searchpage!=null) {
			log.info("Successfully Searched the product!");

		}else {
			throw new Exception("Coudn't search product!");
		}	
	}
	

	@Test
	public void verifyProductPrice() {
		
		String priceSearchPage = searchpage.getProductPrice(1);
		productpage=searchpage.openFirstProduct();
		TestUtil.waitForSeconds(3);
		String priceProdPage=productpage.getPrice();
		Assert.assertEquals(priceProdPage, priceSearchPage, "Product Price Not validated on Product Page");
	}
	
	
	@Test(dependsOnMethods ="verifyProductPrice")
	public void verifyCartAdditionfromProductPage() {
		productpage.setPinCode("411027");
		cart=productpage.addProductToCart();
	}
	
	

	@AfterTest
	public void teardown() {
		log.info("Closing browsers...");
		driver.quit();
		log.info("both browsers closed!");

	}
}
