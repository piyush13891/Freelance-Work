package com.course542.flipkart.tests;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;

@Listeners(com.course542.flipkart.listeners.Listener.class)
public class LoginPageTest extends Driver {
	
	LoginPage loginPage;
	Homepage homepage;
	public static Logger log=LogManager.getLogger(LoginPageTest.class.getName());

	public LoginPageTest(){
		super();
	}

	@BeforeMethod
	public void setUp(ITestContext context){
		
		log.info("=======Launching Application========");
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded ... Traversing to Login Page");
		loginPage = new LoginPage();
		
		context.setAttribute("WebDriver", driver);
	}

	@Test(enabled=true, priority=1)
	public void verifyLoginPopUpElements() throws Exception{
		log.info("=======Login Page Test========");
		loginPage.logInPageVerifyElements();
		//Assert.assertTrue(false,"");  //Added to test Screenshot on Fail - Can be removed
	}
	
	@Test(enabled=true, priority=2)
	public void verifyCreateNewAccountPage() throws Exception{
		log.info("=======Login Page Test========");
		loginPage.verifyCreateNewAccountPage();
	}

	@Test(enabled=true, priority=3)
	public void verifyLoginWithValidDetails() {
		
		log.info("Sending username and password to login page!");
		try {
			homepage=loginPage.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
			if(homepage!=null) {
				log.info("Successfully Logged in!");
				loginPage.logout();
				}
			}
		catch(Exception e) {
			log.error("Login failed!");
			Assert.fail("Homepage=null");
		}
	}
	
	/**
	 * Test to verify Login using invalid Username format (Incorrect email format)
	 */
	@Test(enabled=true, priority=4)
	public void verifyLoginWithInvalidUsernameFormat() {
		
		log.info("Sending username and password to login page!");
		try {
			homepage=loginPage.LoginToHome("InvalidNotPresent", prop.getProperty("pass"));
			if(homepage!=null) {
				
				loginPage.verifyUsernameFormatErrorMessage();
				}
			}
		catch(Exception e) {
			log.error("Test failed!");
			Assert.fail("Homepage=null");
		}
	}
	
	/**
	 * Test to verify Login using invalid Username or password (format is correct)
	 */
	@Test(enabled=true, priority=4)
	public void verifyLoginWithInvalidUsernameOrPassword() {
		
		log.info("Sending username and password to login page!");
		try {
			homepage=loginPage.LoginToHome("test@test.com", "TestPass");
			if(homepage!=null) {
				
				loginPage.verifyInvalidUsernameOrPasswordErrorMessage();
				}
			}
		catch(Exception e) {
			log.error("Test failed!");
			Assert.fail("Homepage=null");
		}
	}

	@AfterMethod
	public void tearDown(){
		log.info("Closing browser");
		driver.close();
		log.info("Browser closed");
	}
}
