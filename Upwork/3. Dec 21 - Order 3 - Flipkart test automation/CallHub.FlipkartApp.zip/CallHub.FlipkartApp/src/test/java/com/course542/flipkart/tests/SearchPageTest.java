package com.course542.flipkart.tests;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.pages.Homepage;
import com.course542.flipkart.pages.LoginPage;
import com.course542.flipkart.pages.ProductPage;
import com.course542.flipkart.pages.SearchPage;
import com.course542.flipkart.util.TestUtil;

public class SearchPageTest extends Driver {

	Homepage homepage;
	SearchPage searchpage;
	LoginPage loginPage;
	ProductPage productpage;
	List<WebElement> list1=new ArrayList<>();
	public static Logger log=LogManager.getLogger(SearchPageTest.class.getName());

	public SearchPageTest() {
		super();
	}

	@BeforeTest
	public void setUp(ITestContext context) throws Exception {
		
		log.info("Initializing Drivers");
		initialize();
		log.info("Driver loaded!");
		loginPage=new LoginPage();
		context.setAttribute("WebDriver", driver);
		
		homepage=loginPage.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
		try{
			//homepage=loginPage.LoginToHome(prop.getProperty("email"), prop.getProperty("pass"));
			if(homepage!=null) {
				log.info("Successfully Logged in! Loading to homepage.");
			}
		}catch(Exception e) {
			log.error("Login failed!");
		}
		
	}
	
	@Test(priority=3)
	public void searchProductFromHomepage() throws Exception {
		
		homepage = new Homepage();
		log.info("typing product name in search bar.....");
		Thread.sleep(3000);
		searchpage = homepage.Search(prop.getProperty("toSearch"));
		
		if(searchpage!=null) {
			log.info("Successfully Searched the product!");

		}else {
			throw new Exception("Coudn't search product!");
		}
	}
	
	//Cannot count all pages as its dynamic so counted first page only
	@Test(priority=1, dependsOnMethods = "searchProductFromHomepage")
	public void getTotalProductSearchCount() {	
		
		int prodSearchCount=searchpage.getSearchCountAll();
		log.info("All Product count" + prodSearchCount);
		Assert.assertTrue(prodSearchCount>0, "Not Found Products");
		
		int prodSearchCountOnPage=searchpage.getSearchCountOnPage();
		log.info("All Product count" + prodSearchCountOnPage);
		Assert.assertTrue(prodSearchCountOnPage>0, "Not Found Products");			
	}

	
	@Test(priority=1, dependsOnMethods = "searchProductFromHomepage")
	public void verifySearchedProducts() {			
		searchpage.verifySearchedProductsList();						
	}
	
	@Test(priority=1, dependsOnMethods = "searchProductFromHomepage")
	public void verifyAFilter() {		
		
		TestUtil.waitForSeconds(5);		
		//setPriceFilters
		searchpage.setMinPrice(30000);			
		searchpage.setMaxPrice(50000);
		
		searchpage.verifySearchedProductPriceRange(30000,50000);
	}
	

	@Test(priority=2, dependsOnMethods = "searchProductFromHomepage")
	public void clickonProductinSearchPage() {		
		productpage=searchpage.openFirstProduct();	
		Assert.assertTrue(productpage.getTitle().toLowerCase().contains(prop.getProperty("toSearch").toLowerCase()),"Product tab title not verified");
	}
	
	@AfterTest
	public void teardown() {
		log.info("Closing browser..");
		driver.quit();
		log.info("Browser closed!");
	}
}
