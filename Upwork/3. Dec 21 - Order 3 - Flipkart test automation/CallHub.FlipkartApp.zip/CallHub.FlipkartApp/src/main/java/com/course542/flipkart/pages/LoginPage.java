package com.course542.flipkart.pages;

import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.TestUtil;

public class LoginPage extends Driver {
	public static Logger log=LogManager.getLogger(LoginPage.class.getName());

	@FindBy(xpath="//span[text()='Login']/../../p/span[text()='Get access to your Orders, Wishlist and Recommendations']")
	WebElement loginPageTexts;
	
	@FindBy(xpath="//button[text()='✕']")
	WebElement xButton;

	@FindBy(xpath="//*[contains(text(),'CONTINUE')]")
	WebElement continueButton;
	
	@FindBy(xpath="//*[contains(text(),'Existing User? Log in')]")
	WebElement existingUser;
	
	@FindBy(xpath="//*[contains(text(),'Enter Mobile number')]")
	WebElement enterMobileNumber;

	@FindBy(xpath="//button[contains(text(),'Login with Password')]")
	WebElement loginwithpass;

	@FindBy(xpath="//span[text()='Enter Email/Mobile number']/../../input")
	WebElement email;

	@FindBy(xpath="//span[text()='Enter Password']/../../input")
	WebElement password;

	@FindBy(xpath="//*[text()='Login']/../../button[@type='submit']")
	WebElement loginButton;

	@FindBy(xpath="//*[text()='Request OTP']")
	WebElement reqOTP;
	
	@FindBy(xpath="//*[text()='New to Flipkart? Create an account']")
	WebElement createNewAccount;
	
	@FindBy(xpath="//*[text()='Forgot?']")
	WebElement forgotPassword;
	
	@FindBy(xpath="//*[text()='Terms of Use']")
	WebElement termsOfuse;
	
	@FindBy(xpath="//*[@id='container']/div/div[1]/div[1]/div[2]/div[3]/div/div/div/div") //Changed to make it dynamic to user
	WebElement username;
	
	@FindBy(xpath="//*[text()='Logout']")
	WebElement logout;
	
	@FindBy(xpath="//*[text()='Login']")
	WebElement login;
	
	@FindBy(xpath="//*[text()='Please enter valid Email ID/Mobile number']")
	WebElement errorUserNameFormat;	
	
	@FindBy(xpath="//*[text()='Your username or password is incorrect']")
	WebElement errorUserNameOrPassword;	
	
	public LoginPage() {
		log.info("initializing driver");
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(30L, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15L, TimeUnit.SECONDS);

	}

	public LoginPage logInPageVerifyElements() throws Exception {
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		Assert.assertTrue(TestUtil.isDisplayed(loginPageTexts));
		Assert.assertTrue(TestUtil.isDisplayed(email));
		Assert.assertTrue(TestUtil.isDisplayed(password));
		Assert.assertTrue(TestUtil.isDisplayed(createNewAccount));
		Assert.assertTrue(TestUtil.isDisplayed(forgotPassword));
		Assert.assertTrue(TestUtil.isDisplayed(termsOfuse));
		Assert.assertTrue(TestUtil.isDisplayed(xButton));
		
		return new LoginPage();

	}
	
	public LoginPage verifyCreateNewAccountPage() throws Exception {
		
		createNewAccount.click();
		TestUtil.waitForSeconds(1);
		
		Assert.assertTrue(TestUtil.isDisplayed(enterMobileNumber));
		Assert.assertTrue(TestUtil.isDisplayed(existingUser));
		Assert.assertTrue(TestUtil.isDisplayed(continueButton));
		Assert.assertTrue(TestUtil.isDisplayed(termsOfuse));
		
		//assertTrue(TestUtil.isDisplayed(xButton));
		existingUser.click();
		TestUtil.waitForSeconds(3);
		Assert.assertTrue(TestUtil.isDisplayed(loginPageTexts));
		
		return new LoginPage();
	}

	public Homepage LoginToHome(String username,String pass) throws Exception {
		
		log.info("Entering email id as username");
		email.sendKeys(username);
		password.sendKeys(pass);
		log.info("Username and Password inserted");
		
		//Click on login
		loginButton.click();
		TestUtil.waitForSeconds(3);
		log.info("Login button clicked.");
		
		return new Homepage();
	}

	
	public LoginPage logout() {
		
		log.info("Logging out of the Application");
		TestUtil.waitForSeconds(3);
		Assert.assertTrue(TestUtil.isDisplayed(username));
		
		Actions action = new Actions(driver);
		action.moveToElement(username).perform();
		
		TestUtil.waitForSeconds(3);
		
		Assert.assertTrue(TestUtil.isDisplayed(logout));
		logout.click();
		
		TestUtil.waitForSeconds(3);
		Assert.assertTrue(TestUtil.isDisplayed(login));		
		log.info("Logged out of the page");
		
		return new LoginPage();
	}
	
	
	public void verifyUsernameFormatErrorMessage() {
		
		log.info("Verifying username format error present");
		Assert.assertTrue(errorUserNameFormat.isDisplayed(), "FAILED || Uername format error message not validated");
		log.info("Verified username error present");
		
		log.info("Verifying username format error message text");
		Assert.assertEquals(errorUserNameFormat.getText(),prop.getProperty("errorMessageInvalidUserNameFormat"), "FAILED || Uername format error message text not validated");
		log.info("Verified username error message text");		
	}
	

	public void verifyInvalidUsernameOrPasswordErrorMessage() {
		
		log.info("Verifying username error present");
		Assert.assertTrue(errorUserNameOrPassword.isDisplayed(), "FAILED ||  Uername error message not validated");
		log.info("Verified username error present");
		
		log.info("Verifying username error message text");
		Assert.assertEquals(errorUserNameOrPassword.getText(),prop.getProperty("errorMessageInvalidUserNamePassword"), "FAILED || Uername error message text not validated");
		log.info("Verified username error message text");		
	}

}
