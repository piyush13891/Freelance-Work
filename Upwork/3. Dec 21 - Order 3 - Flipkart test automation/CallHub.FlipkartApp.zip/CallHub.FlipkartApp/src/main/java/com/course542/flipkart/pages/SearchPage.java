package com.course542.flipkart.pages;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.PageScroll;
import com.course542.flipkart.util.TestUtil;


public class SearchPage extends Driver {

	public static Logger log=LogManager.getLogger(SearchPage.class.getName());

	@FindBy(xpath="//*[@class='bhgxx2 col-12-12']/child::div[@class='_3O0U0u']/child::div/child::div/child::a/child::div[@class='_1-2Iqu row']/child::div[1]/child::div[1]")
	List<WebElement> ProductList;

	@FindBy(xpath="//*[@class='bhgxx2 col-12-12'][1]/child::div[@class='_3O0U0u']/child::div/child::div/child::a/child::div[@class='_1-2Iqu row']/child::div[1]/child::div[1]")
	WebElement firstProduct;

	@FindBy(xpath="//a[@class='_2Xp0TH'][contains(text(),'2')]")
	WebElement tonextpage;

	@FindBy(xpath="//span[@class='_3YmFT8']")
	WebElement topelement;
	
	@FindBy(className = "_1MR4o5")
	WebElement searchHierarchy;
	
	@FindBy(className = "_10Ermr")
	WebElement searchResultCounts;	

	@FindBy(className = "_2kHMtA")
	List<WebElement> productsOnPage;	
	
	@FindBy(xpath = "//*[@class='_1YAKP4']/select")
	WebElement minPriceFilter;	
	
	@FindBy(xpath = "//*[@class='_3uDYxP']/select")
	WebElement maxPriceFilter;	
	
	
	public SearchPage(){
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(30L, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15L, TimeUnit.SECONDS);
	}

	public List<WebElement> returnProductCount() {

		log.info("Scrolling down to the bottom of the page");
		PageScroll.toBottomOfPage();
		log.info("Scrolling to the top of the page");
		PageScroll.toUP();
		log.info("Returning list of products");
		
		List<WebElement> list=ProductList;

		return list;
	}

	public WebElement getFirstProduct() {
		
		TestUtil.waitForSeconds(5);
		log.info("Selecting 1st product");		
		return productsOnPage.get(0);		
	}

	public ProductPage openFirstProduct() {
	
		TestUtil.waitForSeconds(3);
		
		String defaultWindow=driver.getWindowHandle();
		
		log.info("Selecting topmost product");
		WebElement firstProd = getFirstProduct();		
		firstProd.click();
		TestUtil.waitForSeconds(3);
		
		Set<String> handles=driver.getWindowHandles();		
		Iterator<String> handlesItr=handles.iterator();
	 	
		while(handlesItr.hasNext())
		{	
			String childWindow=handlesItr.next();
			if(!defaultWindow.equalsIgnoreCase(childWindow))
    		{
        		log.info("Switching to child window");
                driver.switchTo().window(childWindow);
                log.info("Switched to next tab.");
        	}
		}
		return new ProductPage();
	}

	public void nextpage() {
		log.info("Navigating to next page of products");
		 tonextpage.click();
	}

	public int getSearchCountAll() {
		
		TestUtil.isDisplayed(searchResultCounts);
		String searchRes = searchResultCounts.getText();
		String count = searchRes.split("of")[1].split("result")[0].trim();
		
		return Integer.parseInt(count);
	}
	
	public int getSearchCountOnPage() {	
		log.info("Get Searched item count:");
		return productsOnPage.size();
	}

	public void verifySearchedProductsList() {	
		
		log.info("Verify Searched Items Relevance::");
		//Verify if iphone present in title
		WebElement prodName;
		WebElement price;
		for(WebElement product : productsOnPage) {			
			
			prodName = product.findElement(By.xpath("a/div[2]/div/div"));
			
			Assert.assertTrue(TestUtil.isDisplayed(prodName));			
			Assert.assertTrue(prodName.getText().contains("iPhone"),"Product Name not verified");
			Assert.assertTrue(prodName.getText().contains("APPLE"),"Product Brand not verified");
			
			//Cost will always be >0
			price =  product.findElement(By.xpath("a/div[2]/div[2]/div/div/div"));
			int cost =  Integer.parseInt(price.getText().replace("₹", "").replace(",", ""));		
			
			Assert.assertTrue(TestUtil.isDisplayed(price));		
			Assert.assertTrue(cost>0,"Product Cost not verified");			
		}		
		
		log.info("Verified Searched Items Relevance::");
	}
	
	public void setMinPrice(int price) {	
		
		Assert.assertTrue(TestUtil.isDisplayed(minPriceFilter));		
		log.info("Set Min price for filter" + price);
		Select select =  new Select(minPriceFilter);
		select.selectByValue(String.valueOf(price));	
		TestUtil.waitForSeconds(2);
		Assert.assertEquals(select.getFirstSelectedOption().getText(), "₹"+price, "Min Price Filter Not Applied");
		log.info("Min price filter set to:" + price);
	}
	
	public void setMaxPrice(int price) {		
		
		Assert.assertTrue(TestUtil.isDisplayed(maxPriceFilter));	
		log.info("Set Max price for filter" + price);
		Select select =  new Select(maxPriceFilter);
		select.selectByValue(String.valueOf(price));	
		TestUtil.waitForSeconds(2);
		Assert.assertEquals(select.getFirstSelectedOption().getText(), "₹"+price, "Max Price Filter Not Applied");
		log.info("Max price filter set to:" + price);
		
	}
	
	
	public void verifySearchedProductPriceRange(int minPrice, int maxPrice) {	
		
		log.info("Verify Price range for filter" + minPrice +  " to" + maxPrice);
		WebElement price;
		for(WebElement product : productsOnPage) {					
			
			price =  product.findElement(By.xpath("a/div[2]/div[2]/div/div/div"));			
			int cost =  Integer.parseInt(price.getText().replace("₹", "").replace(",", ""));	
			
			Assert.assertTrue(cost<=maxPrice,"Max Price not verified");			
			Assert.assertTrue(cost>=minPrice,"Min Price not verified");	
		}		

		log.info("Verified Price range for filter" + minPrice +  " to" + maxPrice);
	}		
	

	public String getProductPrice(int productNumber) {	
		
		log.info("Get Prioduct Price");
		int count = 1;
		WebElement price = null;
		for(WebElement product : productsOnPage) {	
			
			price =  product.findElement(By.xpath("a/div[2]/div[2]/div/div/div"));
			if(productNumber==count) {
				break;
			}
		}	
		return price.getText();		
	}		
	
	

}


