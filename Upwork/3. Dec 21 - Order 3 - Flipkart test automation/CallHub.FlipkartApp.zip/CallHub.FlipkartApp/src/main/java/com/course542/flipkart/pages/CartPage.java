package com.course542.flipkart.pages;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.PageScroll;
import com.course542.flipkart.util.TestUtil;

public class CartPage extends Driver {

	public static Logger log=LogManager.getLogger(CartPage.class.getName());

	@FindBy(xpath="//*[text()='Your cart is empty!']")
	WebElement emptyCartMsg;

	@FindBy(xpath="//div[@class='_1psGvi _3BvnxG']")
	WebElement target;

	@FindBy(xpath="//*[contains(text(),'Logout')]")
	WebElement logoutOption;

	@FindBy(xpath="//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")
	WebElement loginButton;
	
	@FindBy(xpath="//*[@class='_1YokD2 _2GoDe3 col-12-12']/div/div/div[@class='_1AtVbE col-12-12']/div[@class='zab8Yh _10k93p']")
	List<WebElement> cartlist;
	
	@FindBy(xpath="//*[text()='Place Order']")
	WebElement placeOrder;

	@FindBy(className="_3dsJAO")
	WebElement removeLink;
	
	//This is Pop-up for Remove
	@FindBy(className="FhkMJZ")
	WebElement removeButton;
	
	@FindBy(xpath="//*[text()='Price details']//..//div//div[4]/div/span/div/div/span")
	WebElement totalPrice;
	
	@FindBy(xpath="//*[@class='_1YokD2 _2GoDe3 col-12-12']/div/div/div[@class='_1AtVbE col-12-12']/div[@class='zab8Yh _10k93p']/div[1]/div/span[1]")
	WebElement itemPrice;	
	
	@FindBy(xpath="//*[@class='_1YokD2 _2GoDe3 col-12-12']/div/div/div[@class='_1AtVbE col-12-12']/div[@class='zab8Yh _10k93p']/div[1]/div[1]/div[1]/a")
	WebElement itemName;		
	
	@FindBy(xpath="//*[text()='Deliver Here']")
	WebElement deliverHere;		
	
	@FindBy(xpath="//*[text()='CONTINUE']")
	WebElement continueOrder;	
		
	public CartPage() {
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(30L, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15L, TimeUnit.SECONDS);		
	}

	public void clickRemove() {
		
		log.info("Remove button clicked");
		PageScroll.toElement(removeLink);
		TestUtil.waitForSeconds(2);
		removeLink.click();
		TestUtil.waitForSeconds(2);
		//removeButton.click();
	}

	public void clickRemove(int num) {
		log.info("To remove 1st product. Removing.....");
		//cartlist.get(num-1).click();
		log.info("Remove button clicked.");
	}

	public void takeCartScreenshot() throws IOException {
		log.info("Traversing to testUtil class..");
		TestUtil.CaptureScreenshot("CartPage");
	}

	public boolean verifyCart(){
		
		String title=driver.getTitle();
		log.info("Title of the page="+title);
		if(title.equals(prop.getProperty("cartPageTitle"))) {
			return true;
		}
		else
			return false;
	}

	public String CartMsg() {
		String msg="";
		if(emptyCartMsg.isDisplayed()) {
			msg=emptyCartMsg.getText();
		}
		return msg;
	}

	public void Logout() {
		Actions a =new Actions(driver);
		a.moveToElement(target).build().perform();
		
		TestUtil.waitForSeconds(2);
		logoutOption.click();
		
		log.info("logout clicked");
	}

	public boolean verifyLogout() {
		log.info("Verifying Login Button");
		if(loginButton.isDisplayed())
			return true;
		return false;
	}
	
	public List<WebElement> getCartList() {
		 
		 log.info("There are "+cartlist.size()+" products in the cart"); 
		 return cartlist;		 
	}

	public int returnCartSize() {
				 
		 log.info("There are "+cartlist.size()+" products in the cart"); 
		 return cartlist.size();		 
	}
	
	public String getTotalPrice() {
		 
		 log.info("There are "+cartlist.size()+" products in the cart"); 
		 Assert.assertTrue(TestUtil.isDisplayed(totalPrice));
		 return totalPrice.getText();		 
	}
	
	public String getCartItemPrice() {

		 log.info("Get cart Item Name"); 
		 Assert.assertTrue(TestUtil.isDisplayed(itemPrice));
		 return itemPrice.getText();		 
	}
	
	public String getCartItemName() {
		 
		 log.info("Get cart Item Name"); 
		 Assert.assertTrue(TestUtil.isDisplayed(itemName));
		 return itemName.getText();		 
	}

	public void placeOrder() {
		
		log.info("Place Order");
		Assert.assertTrue(TestUtil.isDisplayed(placeOrder));
		placeOrder.click();
		
		TestUtil.waitForSeconds(2);
		log.info("Select Delivery address id present"); 
		if(deliverHere.isDisplayed()) {
			deliverHere.click();
		}
		
		log.info("Continue Place Order"); 
		Assert.assertTrue(TestUtil.isDisplayed(continueOrder));
		PageScroll.toElement(continueOrder);
		continueOrder.click();
		
		log.info("get Back");
		driver.navigate().back();		
	}
}
