package com.course542.flipkart.listeners;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.openqa.selenium.OutputType;


public class Listener  implements ITestListener {
	public static Logger log=LogManager.getLogger(Listener.class.getName());
	@Override
	public void onTestStart(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" Started! ");
		log.info(result.getMethod().getMethodName()+" Started! ");
		System.out.println("=============================================================================");

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" test Success! ");
		log.info(result.getMethod().getMethodName()+" test successfull! ");
		System.out.println("=============================================================================");
	}

	@Override
	public void onTestFailure(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" test failed! ");
		log.info(result.getMethod().getMethodName()+" test failed! ");
		System.out.println("=============================================================================");
		
		String methodName =  result.getName().toString().trim();
        ITestContext context = result.getTestContext();
        WebDriver driver = (WebDriver)context.getAttribute("WebDriver");
        takeScreenshot(methodName, driver);			
	}
	
	/**
     * Method to capture screenshot
     */
    public void takeScreenshot(String methodName, WebDriver driver){

        TakesScreenshot ts = (TakesScreenshot)driver;
        File srcFile = ts.getScreenshotAs(OutputType.FILE);
        String path  = System.getProperty("user.dir");

        try {
            FileUtils.copyFile(srcFile, new File(path + "\\screenshots\\" + methodName+ "BugError.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println(result.getMethod().getMethodName()+" test Skipped! ");
		log.info(result.getMethod().getMethodName()+"test skipped! ");
		log.info("Retrying...........");
		System.out.println("=============================================================================");
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	@Override
	public void onStart(ITestContext context) {

	}

	@Override
	public void onFinish(ITestContext context) {

	}

}
