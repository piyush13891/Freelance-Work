package com.course542.flipkart.pages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.TestUtil;

public class Homepage extends Driver{

	public static Logger log=LogManager.getLogger(Homepage.class.getName());

	@FindBy(xpath="//div[@class='_1jA3uo'][1]/child::div[1]/child::div[1]/child::span[1]/child::div[@class='_2aUbKa'][1]")
	WebElement signerName;

	@FindBy(xpath="//*[@title='Search for products, brands and more']")
	WebElement searchBox;

	@FindBy(xpath="//*[@title='Search for products, brands and more']/../../button[@type='submit']")
	WebElement searchButton;
	
	//@FindBy(xpath="//*[text()='Ketaki']")
	@FindBy(xpath="//*[@id='container']/div/div[1]/div[1]/div[2]/div[3]/div/div/div/div")
	WebElement username;
	
	@FindBy(xpath="//div[contains(text(),'APPLE iPhone 12 (Blue, 128 GB')]")
	WebElement searchedProduct;
	
	@FindBy(xpath="//*[@class='xtXmba']")
	List<WebElement> allItemCategoriesList;	
	
	
	@FindBy(className="_7qr1OC")
	WebElement subCategoriesGrid;	
	
	//*[@class='xtXmba' and contains(text(),'Electronics')]
	

	public Homepage(){
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(30L, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15L, TimeUnit.SECONDS);
	}

	public String getTitle() {
		log.info("Title found! Returning to HomePageTest");
		return driver.getTitle();
	}

	public Homepage validateCorrectProfile() {
		Assert.assertTrue(TestUtil.isDisplayed(username));
		return new Homepage();
	}

	public SearchPage Search(String product) throws InterruptedException  {
		
		log.info("Product to search->"+product+". Typing "+product+" in search box.");
		searchBox.sendKeys(product);
		log.info("ImplicitWaiting");
		log.info("Pressing Enter Key");
		searchBox.sendKeys(Keys.ENTER);
		
		TestUtil.waitForSeconds(5);
		Assert.assertTrue(getTitle().toLowerCase().contains(product.toLowerCase()), "Product search failed - Page title not matching");
		
		return new SearchPage();
	}	
	

	public void verifyItemCategoriesListHeader()  {
		
		log.info("Item categories count is verify");
		Assert.assertEquals(allItemCategoriesList.size(),9, "Item Categories count not matching");
		log.info("Item categories count is verified");
		
		StringBuilder allItems =  new StringBuilder();
		
		for(WebElement item : allItemCategoriesList) {
			allItems=allItems.append(item.getText());
			allItems=allItems.append(",");
		}
		log.info("Item categories List ::" + allItems);
		Assert.assertEquals(allItems.toString(), prop.getProperty("allItemsCategoriesList"), "Items list Not Verified");
		log.info("Item categories List Verified::" + allItems);		
	}
	
	
	public void verifyItemSubCategoriesFromTop(String categoryType, String subCategoryType)  {
				
		log.info("Verify Sub Category Item");
		WebElement category = null;
		
		for(WebElement item : allItemCategoriesList) {
			if(item.getText().equals(categoryType)) {
				category = item;
				break;
			}
		}
		
		log.info("Mouse Gover on the Sub Category");
		Actions action = new Actions(driver);
		action.moveToElement(category).perform();
		TestUtil.waitForSeconds(3);

		log.info("Verify Sub Category Menu Item");
		Assert.assertTrue(TestUtil.isDisplayed(subCategoriesGrid));	
		
		WebElement subCategory = category.findElement(By.xpath("//*[text()=\"" + subCategoryType +"\"]")); //Dynamic searching element in Category
		Assert.assertTrue(TestUtil.isDisplayed(subCategory));	
		log.info("Category and Sub Category Verification completed");
		
	}
	
	
}
