package com.course542.flipkart.pages;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.course542.flipkart.base.Driver;
import com.course542.flipkart.util.PageScroll;
import com.course542.flipkart.util.TestUtil;

public class ProductPage extends Driver{
	public static Logger log=LogManager.getLogger(ProductPage.class.getName());
	
	@FindBy(className = "_3v1-ww")
	WebElement addToCart;

	@FindBy(className ="_16Jk6d")
	WebElement productPrice;
	
	@FindBy(className ="_36yFo0")
	WebElement pinCode;	

	@FindBy(xpath="//*[text() = 'Currently out of stock in this area.']")
	WebElement outOfStock;	
	
	
	public ProductPage() {
		PageFactory.initElements(driver, this);
		driver.manage().timeouts().pageLoadTimeout(30L, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(15L, TimeUnit.SECONDS);
	}

	public CartPage addProductToCart() {
		
		log.info("Adding product to cart!");
		addToCart.click();
		log.info("Waiting for adding to cart");
		TestUtil.waitForSeconds(3);
		log.info("Traversing to cart page....");

		return new CartPage();
	}
	
	public String getTitle() {
		log.info("Getting Product Page title");
		return driver.getTitle();
	}

	public String getPrice() {
		log.info("Getting Price from the Product Page::");
		TestUtil.waitForSeconds(2);
		Assert.assertTrue(TestUtil.isDisplayed(productPrice));
		return productPrice.getText();
	}
	
	public void setPinCode(String code) {		
		
		log.info("Detting Pin Code for Product::" + code);
		PageScroll.toElement(pinCode);
		Assert.assertTrue(TestUtil.isDisplayed(pinCode));
		pinCode.sendKeys(code);
		TestUtil.waitForSeconds(2);
		log.info("Pressing Enter Key");
		pinCode.sendKeys(Keys.ENTER);
		TestUtil.waitForSeconds(2);	
		log.info("Pin code set for the product" +  code);
	}
	
	public boolean isOutOfStock() {
		log.info("Checking product Out of Stock for location");
		return TestUtil.isDisplayed(outOfStock);	
	}
}
