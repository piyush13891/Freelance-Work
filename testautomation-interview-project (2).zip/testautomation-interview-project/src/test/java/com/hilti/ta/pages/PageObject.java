package com.hilti.ta.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Locatable;
import org.openqa.selenium.support.ui.ExpectedConditions;
import com.hilti.ta.utils.WebDriverFactory;


public abstract class PageObject {

    protected boolean isElementVisible(final By locator) {
        try {
            final WebElement consentBanner = WebDriverFactory.getWebDriverWait(2).until(ExpectedConditions.presenceOfElementLocated(locator));
            return consentBanner.isDisplayed();
        } catch (final TimeoutException e) {
            // Element not found
            return false;
        }
    }

    protected static void scrollElementInView(final WebDriver webDriver, By elementLocator) {

        WebElement element = webDriver.findElement(elementLocator);
        Actions actions = new Actions(webDriver);

        ((Locatable) webDriver.findElement(elementLocator)).getCoordinates().inViewPort();

        actions.moveToElement(element).
                sendKeys(Keys.DOWN).sendKeys(Keys.DOWN).
                perform();
    }

}
