package com.hilti.ta.steps;

import com.hilti.ta.pages.CategoryPage;
import com.hilti.ta.pages.components.ConsentsComponent;
import com.hilti.ta.utils.WebDriverFactory;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

/**
 * Cucumber steps definition class related to Product Navigation functionality.
 */
public class CategoryNavigationSteps {

	private final CategoryPage categoryPage = new CategoryPage();


	@When("User navigates to category page for {}")
	public void userNavigatesToCategoryPage(final String categoryName) {
		WebDriverFactory.getDriver().navigate().to(WebDriverFactory.getDriver().getCurrentUrl() + "c" + categoryName);
	}

	@Then("User can see different performance level products on category page")
	public void verifyDifferentPerformanceLevelProductsOnCategoryPage() {
		categoryPage.verifyAtLeaseOneProductForEachCategoryPresent();
	}

	@When("User selects performance level {} in the filters")
	public void selectsPerformanceLevelInFilters(final String performanceLevel) throws InterruptedException {
		categoryPage.filterByCategory(performanceLevel);
	}

	@Then("User can see only {} performance level products on category page")
	public void verifyProductsForPerformanceLevelFilter(final String performanceLevel) {
		categoryPage.verifyAllProductsForCategory(performanceLevel);
	}

	@When("User resets the performance level filter")
	public void ResetsPerformanceLevelFilter() throws InterruptedException {
		categoryPage.filterByCategory("No preference");
		categoryPage.verifyAtLeaseOneProductForEachCategoryPresent();
	}

}
