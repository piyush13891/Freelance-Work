package com.hilti.ta.pages;

import com.hilti.ta.pages.components.ConsentsComponent;
import com.hilti.ta.utils.WebDriverFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import java.util.List;

/**
 * Page Object Model representing Product Category Page.
 */
public class CategoryPage extends PageObject {

    private final com.hilti.ta.pages.components.ConsentsComponent consentsComponent = new ConsentsComponent();

    private static final By ultimateProducts = By.cssSelector(".flex-nowrap.bl-h-3.indicator-label-ultimate");
    private static final By premiumProducts = By.cssSelector(".flex-nowrap.bl-h-3.indicator-label-premium");
    private static final By standardProducts = By.cssSelector(".flex-nowrap.bl-h-3.indicator-label-standard");

    private static final By productCategoryClassFilterUltimate= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Ultimate')]");
    private static final By productCategoryClassFilterPremium= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Premium')]");
    private static final By productCategoryClassFilterStandard= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Standard')]");
    private static final By productCategoryClassFilterNoPreference= By.xpath("//button[contains(@class,'custom-radio')]/span[contains(text(),'Premium')]/parent::button/parent::shrd-uic-form-button/preceding-sibling::shrd-uic-form-button/button/span[contains(text(),'No preference')]");

    private static final By allProductItemsPreferencesList = By.cssSelector("div[class*='indicator-label d-flex flex-row flex-nowrap bl-h-3 indicator-label-']");

    public int getCountOfItemsForCategoryOnPage(final String category) {

        int size = 0;
        switch(category.toUpperCase()) {
            case "ULTIMATE":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(ultimateProducts));
                size = WebDriverFactory.getDriver().findElements(ultimateProducts).size();
                break;
            case "PREMIUM":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(premiumProducts));
                size = WebDriverFactory.getDriver().findElements(premiumProducts).size();
                break;
            case "STANDARD":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(standardProducts));
                size = WebDriverFactory.getDriver().findElements(standardProducts).size();
                break;
        }
        return size;
    }

    public void verifyAtLeaseOneProductForEachCategoryPresent() {
        Assert.assertTrue(getCountOfItemsForCategoryOnPage("ultimate") > 0, "FAILED | No Ultimate Products found on Page");
        Assert.assertTrue(getCountOfItemsForCategoryOnPage("premium") > 0, "FAILED | No Premium Products found on Page");
        Assert.assertTrue(getCountOfItemsForCategoryOnPage("standard") > 0, "FAILED | No Standard Products found on Page");
    }

    public int filterByCategory(final String category) throws InterruptedException {
        int size = 0;

        consentsComponent.closeOtherBanners();

        switch(category.toUpperCase()) {
            case "ULTIMATE":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterUltimate));
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterUltimate);
Thread.sleep(1000);
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterUltimate).click();
                consentsComponent.closeOtherBanners();
                break;
            case "PREMIUM":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterPremium));
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterPremium);
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterPremium).click();
                break;
            case "STANDARD":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterStandard));
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterStandard);
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterStandard).click();
                break;
            case "NO PREFERENCE":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterNoPreference));
                consentsComponent.closeOtherBanners();
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterNoPreference);
                WebDriverFactory.getDriver().findElement(productCategoryClassFilterNoPreference).click();
                break;
        }
        return size;
    }

    public void verifyAllProductsForCategory(String category) {

        WebDriverFactory.getWebDriverWait().until(ExpectedConditions.visibilityOfAllElementsLocatedBy(allProductItemsPreferencesList));
        List<WebElement> allProductsPreferences = WebDriverFactory.getDriver().findElements(allProductItemsPreferencesList);

        for(WebElement itemPreference : allProductsPreferences){
            Assert.assertEquals(itemPreference.getText().toUpperCase(), category.toUpperCase(), "FAILED | Found product with Preference other than :: " + category);
        }

        switch(category.toUpperCase()) {
            case "ULTIMATE":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterUltimate));
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterUltimate);
                Assert.assertTrue(getCountOfItemsForCategoryOnPage("ultimate") > 0, "FAILED | No Ultimate Products found on Page");
                break;
            case "PREMIUM":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterPremium));
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterPremium);
                Assert.assertTrue(getCountOfItemsForCategoryOnPage("premium") > 0, "FAILED | No Premium Products found on Page");
                break;
            case "STANDARD":
                WebDriverFactory.getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productCategoryClassFilterStandard));
                scrollElementInView(WebDriverFactory.getDriver(), productCategoryClassFilterStandard);
                Assert.assertTrue(getCountOfItemsForCategoryOnPage("standard") > 0, "FAILED | No Standard Products found on Page");
                break;
        }
    }
}
